<template>
  <div>
    <h1>Student Information</h1>
    <h2>Name:  </h2>
	<h2>CST Number:  </h2>
	<h2>Email:  </h2>
  </div>
</template>
